# Paired pip-show reverse-index measurements

This bundle retains the complete nine-endpoint comparison for uv-dev#1840 at
`6792c507b5b0760f7d07d9de55b0c67492b7ce46` and
`ceaa7293604bc26fa364d5fdf309de0de3e4f82a`. The 216 wall-clock observations are
ordered as the original 108 balanced process pairs. `study.json` records the
source and artifact hashes, exact endpoint requests, controlled metadata recipe,
and estimator configuration.

Run the standalone reanalysis from the extracted directory, passing the manifest
SHA-256 supplied separately by the publisher:

```console
uv run --no-project --no-config --offline --no-managed-python --no-python-downloads --python /path/to/python -- python -I -B analyze.py --bundle . --manifest-sha256 <sha256>
```

The analyzer rechecks every allowlisted file and reconstructs every median,
difference, ratio, 95% pointwise interval, and per-round value with the original
100,000-resample paired-process estimator. These are the actual retained integer
process wall times, not regenerated observations. The original process receipts,
host information, output streams, absolute paths, and binaries remain private.

The comparison used default-feature Rust 1.98.1 `profiling` builds on one Linux
x86-64/ext4 host, with warm filesystem and interpreter-query caches. The 512- and
6,400-package cases are controlled wheel-metadata graphs with eight edges per
package; Jupyter is a real 93-package installed environment. Its full installed
tree is not bundled. The portable data reproduce the numerical analysis, not the
original machine's state or a new performance result. Intervals are pointwise,
and no cold-cache, release-profile, small-environment, or cross-platform benefit
is implied. All adverse and inconclusive endpoints remain included.
