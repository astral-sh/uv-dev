#!/usr/bin/env python3
"""Compare paired Criterion process rounds without treating iterations as samples."""

from __future__ import annotations

import argparse
import json
import math
import random
import statistics
import tarfile
from pathlib import Path
from typing import Any


def normalized_samples(value: dict[str, Any]) -> list[float]:
    iterations = value["iters"]
    times = value["times"]
    if not iterations or len(iterations) != len(times):
        raise ValueError("Criterion sample arrays must be nonempty and equally sized")
    result = []
    for count, elapsed in zip(iterations, times, strict=True):
        if count <= 0 or elapsed <= 0:
            raise ValueError("Criterion iteration counts and wall times must be positive")
        sample = elapsed / count
        if not math.isfinite(sample):
            raise ValueError("Criterion sample is not finite")
        result.append(sample)
    return result


def read_sample(path: str, archive: tarfile.TarFile | None) -> list[float]:
    if archive is None:
        value = json.loads(Path(path).read_text())
    else:
        member = archive.extractfile(path)
        if member is None:
            raise ValueError(f"Not a regular archive member: {path}")
        with member:
            value = json.load(member)
    return normalized_samples(value)


def percentile(sorted_values: list[float], fraction: float) -> float:
    position = fraction * (len(sorted_values) - 1)
    lower = math.floor(position)
    upper = math.ceil(position)
    return sorted_values[lower] + (sorted_values[upper] - sorted_values[lower]) * (
        position - lower
    )


def interval(values: list[float], confidence: float) -> list[float]:
    values.sort()
    tail = (1 - confidence) / 2
    return [percentile(values, tail), percentile(values, 1 - tail)]


def compare(
    control: list[list[float]],
    candidate: list[list[float]],
    *,
    resamples: int,
    seed: int,
    confidence: float,
    expected_sample_groups: int | None = None,
    expected_process_rounds: int | None = None,
) -> dict[str, Any]:
    if not control or len(control) != len(candidate):
        raise ValueError("Provide equally many control and candidate process rounds")
    if expected_process_rounds is not None and (
        expected_process_rounds <= 0 or len(control) != expected_process_rounds
    ):
        raise ValueError("Provide the planned number of paired process rounds")
    if any(len(a) != len(b) for a, b in zip(control, candidate, strict=True)):
        raise ValueError("Each paired round must contain equally many sample groups")
    groups_per_round = len(control[0])
    if groups_per_round == 0 or any(len(run) != groups_per_round for run in control):
        raise ValueError("All process rounds must contain equally many sample groups")
    if expected_sample_groups is not None and groups_per_round != expected_sample_groups:
        raise ValueError("Each process round must contain the planned sample-group count")
    if resamples < 1000 or not 0 < confidence < 1:
        raise ValueError("Use at least 1,000 resamples and a confidence level in (0, 1)")

    control_point = statistics.median([x for run in control for x in run])
    candidate_point = statistics.median([x for run in candidate for x in run])
    control_medians = []
    candidate_medians = []
    ratios = []
    differences = []
    rng = random.Random(seed)
    rounds = range(len(control))
    for _ in range(resamples):
        control_draw = []
        candidate_draw = []
        # Resample matched process rounds together, then resample the recorded groups within
        # each selected round. Individual benchmark iterations were not separately observed.
        for index in rng.choices(rounds, k=len(control)):
            control_draw.extend(rng.choices(control[index], k=len(control[index])))
            candidate_draw.extend(rng.choices(candidate[index], k=len(candidate[index])))
        baseline = statistics.median(control_draw)
        changed = statistics.median(candidate_draw)
        control_medians.append(baseline)
        candidate_medians.append(changed)
        ratios.append(changed / baseline)
        differences.append(changed - baseline)

    return {
        "method": "paired-process-round hierarchical percentile bootstrap of the pooled median of normalized sample-group average times",
        "confidence_level": confidence,
        "resamples": resamples,
        "seed": seed,
        "process_rounds": len(control),
        "sample_groups_per_round": [len(run) for run in control],
        "control_median_ns": control_point,
        "control_median_ci_ns": interval(control_medians, confidence),
        "candidate_median_ns": candidate_point,
        "candidate_median_ci_ns": interval(candidate_medians, confidence),
        "candidate_control_ratio": candidate_point / control_point,
        "candidate_control_ratio_ci": interval(ratios, confidence),
        "candidate_minus_control_ns": candidate_point - control_point,
        "candidate_minus_control_ci_ns": interval(differences, confidence),
        "per_round": [
            {
                "control_median_ns": statistics.median(a),
                "candidate_median_ns": statistics.median(b),
                "candidate_control_ratio": statistics.median(b) / statistics.median(a),
            }
            for a, b in zip(control, candidate, strict=True)
        ],
    }


def self_test() -> None:
    samples = normalized_samples({"iters": [1, 2, 4], "times": [10, 20, 40]})
    assert samples == [10, 10, 10]
    result = compare(
        [[10.0] * 40] * 3,
        [[8.0] * 40] * 3,
        resamples=1000,
        seed=1,
        confidence=0.95,
        expected_sample_groups=40,
        expected_process_rounds=3,
    )
    assert result["candidate_control_ratio_ci"] == [0.8, 0.8]
    assert result["candidate_minus_control_ci_ns"] == [-2.0, -2.0]
    assert result["sample_groups_per_round"] == [40, 40, 40]
    for control, candidate, expected, expected_rounds in [
        ([[10.0], [10.0, 10.0]], [[8.0], [8.0, 8.0]], None, None),
        ([[10.0]], [[8.0]], 40, None),
        ([[10.0] * 40], [[8.0] * 40], 40, 12),
    ]:
        try:
            compare(
                control,
                candidate,
                resamples=1000,
                seed=1,
                confidence=0.95,
                expected_sample_groups=expected,
                expected_process_rounds=expected_rounds,
            )
        except ValueError:
            pass
        else:
            raise AssertionError("Unplanned process or sample-group counts must be rejected")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--control", nargs="+")
    parser.add_argument("--candidate", nargs="+")
    parser.add_argument("--resamples", type=int, default=100_000)
    parser.add_argument("--seed", type=int, default=20260911)
    parser.add_argument("--confidence", type=float, default=0.95)
    parser.add_argument("--expected-sample-groups", type=int)
    parser.add_argument("--expected-process-rounds", type=int)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        print("self-test passed")
        return
    if not args.control or not args.candidate:
        parser.error("--control and --candidate are required")
    archive = tarfile.open(args.archive, "r:*") if args.archive else None
    try:
        result = compare(
            [read_sample(path, archive) for path in args.control],
            [read_sample(path, archive) for path in args.candidate],
            resamples=args.resamples,
            seed=args.seed,
            confidence=args.confidence,
            expected_sample_groups=args.expected_sample_groups,
            expected_process_rounds=args.expected_process_rounds,
        )
    finally:
        if archive is not None:
            archive.close()
    result["control_sources"] = args.control
    result["candidate_sources"] = args.candidate
    if args.archive:
        result["archive"] = str(args.archive)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
