"""Offline exact-order reanalysis of the PR1840 pip-show measurements."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import types
from typing import Any

SCHEMA = "uv-future.pr1840-portable-manifest.v1"
STUDY_SHA = "122dc8bf8777d3d70609416f4ad0830f46375b61f4ca9c81ff2f8e32f5940ac2"
SAMPLES_SHA = "e1ea2cfc4db32ffe6726b4175b388a7af93e6d74ab2a25f0ba534dadea80486f"
ANALYSIS_SHA = "3054d2d5dfbb4d63430a496cbbfebd7477b2a3a8a543a6890cdba3ab4de5dd2e"
SCHEDULE_SHA = "b976eac08e8814c15a58992c5955fda31e805d8f4576748696621f43acbee253"
ESTIMATOR_SHA = "2adb862c2e8ab839921e1510e8215e5195f19bcf8745834ff86f05fc02cbe050"
ESTIMATOR_ARGS = {"resamples": 100000, "seed": 20260911, "confidence": 0.95,
    "expected_sample_groups": 1, "expected_process_rounds": 12}
PAYLOAD = frozenset({"README.md", "study.json", "samples.json", "analysis.json", "estimator.py", "analyze.py"})
MAX_MEMBER = 4 * 1024 * 1024
MAX_TOTAL = 32 * 1024 * 1024
SOURCE_PAIR = {"base": ("6792c507b5b0760f7d07d9de55b0c67492b7ce46", "47d4046df3ea3af5de32020e1d7f732647c2e797"),
    "candidate": ("ceaa7293604bc26fa364d5fdf309de0de3e4f82a", "ac981064bc93f04d84309043170ec66f49657faf")}
ENDPOINTS = ("jupyter-single", "jupyter-ten", "jupyter-all", "graph-512-single", "graph-512-32",
    "graph-512-all", "graph-6400-single", "graph-6400-32", "graph-6400-all")
RESULT_FIELDS = frozenset({"endpoint", "fixture", "requested_count", "method", "confidence_level",
    "resamples", "seed", "process_rounds", "sample_groups_per_round", "control_median_ns",
    "control_median_ci_ns", "candidate_median_ns", "candidate_median_ci_ns", "candidate_control_ratio",
    "candidate_control_ratio_ci", "candidate_minus_control_ns", "candidate_minus_control_ci_ns",
    "per_round", "process_provenance"})


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return {"sha256": digest(data), "bytes": len(data)}


def pretty(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def parse_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    def finite_float(text):
        value = float(text)
        require(math.isfinite(value), "non-finite JSON")
        return value
    require(isinstance(data, bytes) and len(data) <= MAX_TOTAL, "JSON size differs")
    return json.loads(data, object_pairs_hook=pairs, parse_float=finite_float,
        parse_constant=lambda _: (_ for _ in ()).throw(RuntimeError("non-finite JSON")))


def hash_string(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None and value != "0" * 64


def valid_identity(value):
    return isinstance(value, dict) and set(value) == {"sha256", "bytes"} and hash_string(value["sha256"]) \
        and type(value["bytes"]) is int and value["bytes"] > 0


def read_regular(path, maximum=MAX_MEMBER):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path, "noncanonical file")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(descriptor)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= maximum, "nonregular or oversized file")
        chunks, remaining = [], before.st_size
        while remaining:
            chunk = os.read(descriptor, min(remaining, 1024 * 1024))
            require(chunk, "short file")
            chunks.append(chunk)
            remaining -= len(chunk)
        require(os.read(descriptor, 1) == b"", "file grew")
        after = os.fstat(descriptor)
        named = path.lstat()
        fields = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
        require(fields(before) == fields(after) == fields(named), "input changed during read")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def content_scan(data):
    text = data.decode("utf-8")
    require(re.search(r"(?:/(?:Users|home|private|tmp)/|file://|[a-z0-9]+-uv-dev(?:-[0-9]+)?|devbox-[0-9]|BEGIN [A-Z ]*PRIVATE KEY|github_pat_|gh[pousr]_[A-Za-z0-9]{20}|Bearer[ ]+[A-Za-z0-9])", text, re.I) is None,
        "private content in portable payload")


def make_schedule(endpoints: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for block in range(1, 13):
        start = (block - 1) % len(endpoints)
        for position in [*range(start, len(endpoints)), *range(start)]:
            result.append(
                {
                    "block": block,
                    "endpoint": endpoints[position]["id"],
                    "order": "AB" if (block + position) % 2 == 0 else "BA",
                }
            )
    return result


def validate_study(data):
    require(digest(data) == STUDY_SHA, "fixed study changed")
    value = parse_json(data)
    require(type(value) is dict and set(value) == {"schema", "source", "build", "method", "fixtures",
        "endpoints", "schedule", "qualification", "private_admission", "readme"}
        and value["schema"] == "uv-future.pr1840-portable-study.v1", "study schema differs")
    require({role: (item["head"], item["tree"]) for role, item in value["source"]["pair"].items()} == SOURCE_PAIR,
        "exact source pair differs")
    arguments = value["method"]["arguments"]
    require(type(arguments) is dict and set(arguments) == set(ESTIMATOR_ARGS)
        and all(type(arguments[key]) is int for key in ("resamples", "seed", "expected_sample_groups", "expected_process_rounds"))
        and type(arguments["confidence"]) is float and math.isfinite(arguments["confidence"])
        and all(type(value["method"][key]) is int for key in ("timed_processes", "qualification_processes", "pairs", "endpoints"))
        and arguments == ESTIMATOR_ARGS and value["method"]["timed_processes"] == 216
        and value["method"]["qualification_processes"] == 18 and value["method"]["pairs"] == 108
        and value["method"]["endpoints"] == 9 and value["method"]["interval_scope"] == "pointwise"
        and value["method"]["estimator"] == {"sha256": ESTIMATOR_SHA, "bytes": 8313}, "method differs")
    endpoints = value["endpoints"]
    require(type(endpoints) is list and tuple(item["id"] for item in endpoints) == ENDPOINTS, "endpoint matrix differs")
    for item in endpoints:
        require(set(item) == {"id", "fixture", "requested_count", "requests", "request_identity"}
            and type(item["requested_count"]) is int and item["requested_count"] > 0
            and type(item["requests"]) is list and item["requests"] == sorted(set(item["requests"]))
            and len(item["requests"]) == item["requested_count"]
            and all(type(name) is str and re.fullmatch(r"[a-z0-9][a-z0-9.-]*", name) for name in item["requests"])
            and valid_identity(item["request_identity"])
            and identity(pretty(item["requests"])) == item["request_identity"], "exact endpoint request differs")
    require(value["schedule"] == make_schedule(endpoints)
        and digest(pretty(value["schedule"])) == SCHEDULE_SHA, "predeclared schedule differs")
    qualification = value["qualification"]
    require(type(qualification) is list and len(qualification) == 18, "qualification inventory differs")
    for number, item in enumerate(qualification):
        role = ("base", "candidate")[number % 2]
        endpoint = endpoints[number // 2]
        require(set(item) == {"endpoint", "role", "source_head", "source_tree", "record", "request_sha256",
            "exit_code", "stdout", "stderr"} and item["endpoint"] == endpoint["id"] and item["role"] == role
            and (item["source_head"], item["source_tree"]) == SOURCE_PAIR[role]
            and type(item["exit_code"]) is int and item["exit_code"] == 0
            and item["request_sha256"] == endpoint["request_identity"]["sha256"]
            and all(valid_identity(item[key]) for key in ("record", "stdout", "stderr")),
            "qualification proof differs")
    require(all(left["stdout"] == right["stdout"] and left["stderr"] == right["stderr"]
        for left, right in zip(qualification[::2], qualification[1::2], strict=True)), "qualified outputs differ")
    require(valid_identity(value["readme"])
        and all(valid_identity(item) for item in value["private_admission"].values()), "fixed provenance differs")
    return value


def validate_samples(value, study):
    require(type(value) is list and len(value) == 216, "complete 216-sample projection required")
    expected = [{**pair, "arm": arm} for pair in study["schedule"] for arm in pair["order"]]
    seen = set()
    for index, (item, planned) in enumerate(zip(value, expected, strict=True)):
        require(type(item) is dict and set(item) == {"index", "block", "endpoint", "order", "arm", "elapsed_ns", "original_record"}
            and type(item["index"]) is int and item["index"] == index
            and type(item["block"]) is int and {key: item[key] for key in planned} == planned
            and type(item["elapsed_ns"]) is int and 0 < item["elapsed_ns"] <= 120000000000
            and valid_identity(item["original_record"]), "sample schema, order, or native clock differs")
        require(item["original_record"]["sha256"] not in seen, "duplicate source-record proof")
        seen.add(item["original_record"]["sha256"])
    require(len(seen) == 216, "source-record inventory differs")
    return value


def load_estimator(source):
    require(identity(source) == {"sha256": ESTIMATOR_SHA, "bytes": 8313}, "unchanged estimator required")
    module = types.ModuleType("verified_pr1840_estimator")
    module.__file__ = "verified:estimator.py"
    exec(compile(source, module.__file__, "exec"), module.__dict__)
    return module


def recompute(study, rows, estimator_source):
    estimator = load_estimator(estimator_source)
    estimator.self_test()
    results = []
    for endpoint in study["endpoints"]:
        control, candidate, provenance = [], [], []
        for block in range(1, 13):
            pair = [item for item in rows if item["endpoint"] == endpoint["id"] and item["block"] == block]
            require(len(pair) == 2 and {item["arm"] for item in pair} == {"A", "B"}, "whole pair missing")
            values = {item["arm"]: item for item in pair}
            control.append([float(values["A"]["elapsed_ns"])])
            candidate.append([float(values["B"]["elapsed_ns"])])
            provenance.append({"block": block, "A": values["A"]["original_record"], "B": values["B"]["original_record"]})
        result = {"endpoint": endpoint["id"], "fixture": endpoint["fixture"], "requested_count": endpoint["requested_count"],
            **estimator.compare(control, candidate, **ESTIMATOR_ARGS), "process_provenance": provenance}
        require(set(result) == RESULT_FIELDS, "estimator output schema differs")
        results.append(result)
    require(len(results) == 9, "all pointwise estimates required")
    return results


def admit_payload(payload, manifest):
    require(type(payload) is dict and set(payload) == PAYLOAD
        and type(manifest) is dict and set(manifest) == {"schema", "payload"} and manifest["schema"] == SCHEMA
        and type(manifest["payload"]) is dict and set(manifest["payload"]) == PAYLOAD
        and all(valid_identity(item) for item in manifest["payload"].values())
        and manifest["payload"] == {name: identity(data) for name, data in sorted(payload.items())},
        "exact allowlisted payload differs")
    require(all(type(data) is bytes and 0 < len(data) <= MAX_MEMBER for data in payload.values())
        and sum(map(len, payload.values())) <= MAX_TOTAL, "portable byte bounds differ")
    require(payload["analyze.py"] == read_regular(Path(__file__).resolve()), "analyzer source differs")
    for name, data in payload.items():
        if name != "analyze.py":
            content_scan(data)
    study = validate_study(payload["study.json"])
    require(identity(payload["README.md"]) == study["readme"], "public explanation differs")
    require(digest(payload["samples.json"]) == SAMPLES_SHA and digest(payload["analysis.json"]) == ANALYSIS_SHA,
        "frozen raw or analysis projection differs")
    rows = validate_samples(parse_json(payload["samples.json"]), study)
    analysis = recompute(study, rows, payload["estimator.py"])
    expected = parse_json(payload["analysis.json"])
    require(type(expected) is list and len(expected) == 9
        and all(type(item) is dict and set(item) == RESULT_FIELDS for item in expected)
        and pretty(expected) == pretty(analysis), "complete pointwise reanalysis differs")
    return {"schema": "uv-future.pr1840-portable-admission.v1", "accepted": True,
        "study": study, "analysis": analysis, "publication_authorized": False}


def admit_portable(bundle, expected_manifest_sha256):
    bundle = Path(os.path.abspath(bundle))
    require(bundle.is_absolute() and bundle.resolve(strict=True) == bundle and bundle.is_dir()
        and not bundle.is_symlink() and hash_string(expected_manifest_sha256), "external manifest pin required")
    require({item.name for item in bundle.iterdir()} == PAYLOAD | {"manifest.json"}, "portable file inventory differs")
    manifest_data = read_regular(bundle / "manifest.json")
    require(digest(manifest_data) == expected_manifest_sha256, "manifest digest differs")
    payload = {name: read_regular(bundle / name) for name in sorted(PAYLOAD)}
    return admit_payload(payload, parse_json(manifest_data)) | {"manifest_sha256": expected_manifest_sha256}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    args = parser.parse_args()
    print(json.dumps(admit_portable(args.bundle, args.manifest_sha256), indent=2, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
