"""Hash-pinned additive guard for the frozen PR252 paired-data analyzer.

This module changes only raw fixed-design contrast admission. It grants no
permission to build, collect, calibrate, time, or publish a benchmark study.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import sys
from pathlib import Path
from types import ModuleType
from typing import Sequence

HERE = Path(__file__).resolve().parent
FROZEN = HERE.parent / "pr252-production-api-plan-20260925-v1"
MAX_INPUT_BYTES = 16 * 1024 * 1024
READ_CHUNK_BYTES = 64 * 1024
PINS = {
    "plan.json": "4d935e0fded11b083a324cdcc7e5ea255bdd5ba007bbe0697af1a8ef21419c7f",
    "analyze_pairs.py": "b89f53f1182a22616938e566030dca6c9db226d7735a39084225e907e5b85770",
    "admission-clarification-v1.json": "5b34f92da4eca4cc8e0e620e8551a3e13da41aca09e7462cec74a4583ac8d087",
}


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_ordinary_bytes(path: Path) -> bytes:
    """Read at most MAX_INPUT_BYTES + 1 from one no-follow regular-file handle."""
    if not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_NONBLOCK"):
        raise ValueError("No-follow/nonblocking file opens are unavailable")
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0)
    descriptor = None
    try:
        descriptor = os.open(path, flags)
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or not 0 <= before.st_size <= MAX_INPUT_BYTES:
            raise ValueError(f"Invalid bounded ordinary input: {path}")
        chunks = []
        remaining = MAX_INPUT_BYTES + 1
        while remaining:
            chunk = os.read(descriptor, min(READ_CHUNK_BYTES, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        data = b"".join(chunks)
        if len(data) > MAX_INPUT_BYTES:
            raise ValueError(f"Invalid bounded ordinary input: {path}")
        after = os.fstat(descriptor)
        identity_fields = ("st_dev", "st_ino", "st_mode", "st_size", "st_mtime_ns", "st_ctime_ns")
        if len(data) != before.st_size or any(
            getattr(before, field) != getattr(after, field) for field in identity_fields
        ):
            raise ValueError(f"Input changed while reading: {path}")
        return data
    except OSError as error:
        raise ValueError(f"Invalid bounded ordinary input: {path}") from error
    finally:
        if descriptor is not None:
            os.close(descriptor)


def load_frozen() -> tuple[ModuleType, dict, dict[Path, bytes]]:
    pinned = {}
    for name, expected in PINS.items():
        path = FROZEN / name
        data = read_ordinary_bytes(path)
        if digest_bytes(data) != expected:
            raise ValueError(f"Frozen input hash mismatch: {name}")
        pinned[path] = data
    source_path = FROZEN / "analyze_pairs.py"
    analyzer = ModuleType("pr252_hash_pinned_frozen_analyzer")
    analyzer.__file__ = str(source_path)
    # Execute the exact bytes just hashed, not a second filesystem read.
    exec(compile(pinned[source_path], str(source_path), "exec"), analyzer.__dict__)
    plan = json.loads(pinned[FROZEN / "plan.json"])
    return analyzer, plan, pinned


def validate_fixed_design(design: dict, expected: list[tuple[str, str]]) -> None:
    """Check the raw list before the frozen analyzer can collapse duplicate keys."""
    rows = design.get("contrasts")
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("Invalid raw fixed-design contrast list")
    keys = [(row.get("case"), row.get("clock")) for row in rows]
    if keys != expected:
        raise ValueError("Duplicate, missing, extra, or reordered fixed-design contrast")


def main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["choose", "report"])
    parser.add_argument("observations", type=Path)
    parser.add_argument("--design", type=Path)
    args = parser.parse_args(argv)

    analyzer, plan, pinned = load_frozen()
    snapshots = {FROZEN / "plan.json": pinned[FROZEN / "plan.json"]}

    def retain(path: Path) -> bytes:
        if path not in snapshots:
            snapshots[path] = read_ordinary_bytes(path)
        return snapshots[path]

    retain(args.observations)
    if args.design is not None:
        design = json.loads(retain(args.design))
        if args.mode == "report":
            validate_fixed_design(design, analyzer.contrasts(plan))
    elif args.mode == "report":
        raise ValueError("A/B requires the previously sealed A/A design")

    def frozen_read(path: Path) -> dict:
        if path not in snapshots:
            raise ValueError(f"Unexpected frozen-analyzer read: {path}")
        return json.loads(snapshots[path])

    def frozen_digest(path: Path) -> str:
        if path not in snapshots:
            raise ValueError(f"Unexpected frozen-analyzer digest: {path}")
        return digest_bytes(snapshots[path])

    # The preflight and unchanged analyzer consume the same retained byte strings.
    # No design or observation path is reopened between validation and hashing.
    analyzer.read = frozen_read
    analyzer.digest = frozen_digest
    frozen_argv = [str(FROZEN / "analyze_pairs.py"), args.mode, str(args.observations)]
    if args.design is not None:
        frozen_argv.extend(["--design", str(args.design)])
    saved_argv = sys.argv
    try:
        sys.argv = frozen_argv
        analyzer.main()
    finally:
        sys.argv = saved_argv


if __name__ == "__main__":
    main()
