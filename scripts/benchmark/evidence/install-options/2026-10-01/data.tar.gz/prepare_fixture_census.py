"""Read the six pinned #1559 TOML inputs; print a source-only package census."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import tomllib
from pathlib import Path

REPOSITORY = Path(__file__).resolve().parent
OWNER = "24fec0b6e89fe6a9d860cb93d52a13fdcb02c4b2"
FIXTURES = REPOSITORY / "fixtures"
ABSENT = "uv-benchmark-filter-definitely-absent"


def normalized(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def source(relative: str) -> bytes:
    return (REPOSITORY / "owner" / Path(relative).name).read_bytes()


def main() -> None:
    manifest_bytes = source("scripts/benchmark/fixtures.json")
    environments_bytes = source("scripts/benchmark/environments.json")
    manifest = {item["filename"]: item for item in json.loads(manifest_bytes)}
    environments = json.loads(environments_bytes)
    if [item["name"] for item in environments] != ["packse", "uv_docs", "prefect"]:
        raise ValueError("Unexpected owner corpus")
    corpora = []
    for environment in environments:
        project = environment["project"]
        inputs = {}
        decoded = {}
        for suffix in ["pyproject.toml", "lock"]:
            filename = f"{project}.{suffix}"
            path = FIXTURES / filename
            if not path.is_file() or path.is_symlink():
                raise ValueError(f"Missing ordinary fixture: {path}")
            payload = path.read_bytes()
            if hashlib.sha256(payload).hexdigest() != manifest[filename]["sha256"]:
                raise ValueError(f"Fixture identity mismatch: {filename}")
            inputs[suffix] = {"path": "fixtures/" + filename, "bytes": len(payload), **manifest[filename]}
            decoded[suffix] = tomllib.loads(payload.decode())
        pyproject = decoded["pyproject.toml"]
        lock = decoded["lock"]
        project_name = normalized(pyproject["project"]["name"])
        if pyproject.get("tool", {}).get("uv", {}).get("workspace") or lock.get("manifest"):
            raise ValueError("Workspace/manifest census requires a new reviewed rule")
        rows = []
        registry_names = set()
        for index, package in enumerate(lock["package"]):
            name = normalized(package["name"])
            package_source = package["source"]
            local = any(key in package_source for key in ["directory", "editable", "path", "virtual"])
            if "registry" in package_source:
                registry_names.add(name)
            rows.append({"lock_index": index, "name": name, "version": package.get("version"), "source": package_source, "is_local": local})
        names = sorted({row["name"] for row in rows})
        if ABSENT in names:
            raise ValueError("Miss sentinel occurs in corpus")
        expected_local = [(project_name, {"editable": "."})]
        if [(row["name"], row["source"]) for row in rows if row["is_local"]] != expected_local:
            raise ValueError("Unexpected local-source census")
        hit = normalized(environment["installed-requirement"].split("==", 1)[0])
        if hit not in registry_names:
            raise ValueError("Owner's installed requirement is not a registry hit")
        corpora.append({
            "id": environment["name"], "owner_environment": environment,
            "inputs": inputs, "project": project_name, "members": [],
            "members_source": "absent lock manifest deserializes to ResolverManifest::default()",
            "targets": rows, "registry_names": sorted(registry_names),
            "known_hit": hit, "absent": ABSENT,
            "lock_row_count": len(rows), "unique_name_count": len(names),
            "sorted_unique_names_sha256": hashlib.sha256(("\n".join(names) + "\n").encode()).hexdigest(),
            "active_environment_census": False,
        })
    print(json.dumps({
        "schema": "uv-pr252-fixture-census-v1", "owner": OWNER,
        "owner_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "owner_environments_sha256": hashlib.sha256(environments_bytes).hexdigest(),
        "corpora": corpora, "product_executed": False,
    }, sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
