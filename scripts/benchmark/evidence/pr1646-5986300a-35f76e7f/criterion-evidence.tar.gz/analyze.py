"""Offline reconstruction of the exact PR1646 paired Criterion study."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import stat
import statistics

SCHEMA = "uv-future.pr1646-portable-manifest.v1"
READER_SHA = "ea621c3c1d4411008e6745c319a78103238a8d39c123877566f6bdf51481e67d"
TERMINAL_SHA = "b7fc49e257f03b26139b8f35f25b3c558366c4cf8aeec616cba1aea033a98f56"
RESULT_SHA = "90f1fd121791af9fcf68bab3593785ef1cd1a485c8acb24e73d85c08c4a4827f"
BUILD_ADMISSION_SHA = "c34c15f63bb10b489a33dacd8ec7433e5be35dd2c22ed06e035e37d0c7909d96"
RAW_NAMES = ("sample.json", "estimates.json", "benchmark.json", "tukey.json")
PRIMARY = "wheel_install/replace_copy/flask"
CASES = tuple(f"wheel_install/{operation}/{package}" for package in ("flask", "jupyterlab", "numpy", "sympy") for operation in ("fresh_hardlink", "replace_hardlink", "fresh_copy", "replace_copy"))
SOURCES = {
    "parent": {"head": "5986300a36998eff55707c0c7aaced0c9249702e", "tree": "fb46e52553aa24159fafaa54b34d5995ad1f3d62", "parents": ["40c31830dce72d5eecea5f87c850ba2498b93f34"]},
    "candidate": {"head": "35f76e7f491e6113772b456298251042d799d981", "tree": "c670fcbcb8334a1d19ecd5fee2e669d941c5668b", "parents": ["5986300a36998eff55707c0c7aaced0c9249702e"]},
}
PROFILE = {"opt_level": "3", "debuginfo": 2, "debug_assertions": False, "overflow_checks": False, "test": True}
ARTIFACTS = {
    "parent": {"sha256": "1f1869fb0036784344bf07bf1ef41f735b8eace0f3fbd0b0ad124a25f48f95ac", "bytes": 7927120, "mode": 493, "format": "Mach-O-arm64", "cargo_profile": PROFILE},
    "candidate": {"sha256": "98563e40e58b8780e9fd343e41d0a5f656ac1f00efc9fd6c3b9724cb8c84bf34", "bytes": 7928048, "mode": 493, "format": "Mach-O-arm64", "cargo_profile": PROFILE},
}
FIXTURES = [
    {"name": "flask-3.1.2-py3-none-any.whl", "bytes": 103308, "sha256": "ca1d8112ec8a6158cc29ea4858963350011b5c846a414cdb7a954aa9e967d03c"},
    {"name": "jupyterlab-4.4.7-py3-none-any.whl", "bytes": 12291583, "sha256": "808bae6136b507a4d18f04254218bfe71ed8ba399a36ef3280d5f259e69abf80"},
    {"name": "numpy-2.2.6-cp311-cp311-manylinux_2_17_aarch64.manylinux2014_aarch64.whl", "bytes": 14312005, "sha256": "b64d8d4d17135e00c8e346e0a738deb17e754230d7e0810ac5012750bbd85a5a"},
    {"name": "sympy-1.14.0-py3-none-any.whl", "bytes": 6299353, "sha256": "e091cc3e99d2141a0ba2847328f5479b05d94a6635cb96148ccb3f34671bd8f5"},
]
METHOD = {"processes": 32, "timed_processes": 28, "case_observations": 88, "raw_records": 704,
    "primary_pairs": 12, "samples_per_case": 20, "resamples": 20000, "seed": 1646, "confidence": 0.95,
    "ratio": "candidate/parent", "estimator": "geometric mean of matched per-process median ratios",
    "interval": "percentile paired bootstrap over log ratios", "context": "two descriptive complete-suite pairs; no per-case interval",
    "target": "aarch64-apple-darwin", "rust_toolchain": "1.98.1", "criterion": "5.0.1",
    "requested_profile": "profiling", "clock": "ordinary Criterion wall time, not CodSpeed instrumentation",
    "timed_work": "production wheel installation; extraction, RECORD healing, per-iteration setup and output destruction excluded",
    "historical_codspeed_attribution": "unresolved", "local_host_only": True}
README = """# PR1646 exact-source wheel-install replay

This evidence accompanies [PR1646](https://github.com/astral-sh/uv-dev/pull/1646) and reuses the real-wheel workload owned by [PR1477](https://github.com/astral-sh/uv-dev/pull/1477). The source pair, actual retained executable identities, fixture hashes, requested profile, observed Cargo profile, and complete invocation order are in `study.json`.

Run `uv run --no-project --no-config --offline --no-managed-python --no-python-downloads -- python -I -B analyze.py --bundle . --manifest-sha256 <externally-pinned-sha256>`. No product executable, network, or third-party Python package is needed for reanalysis. Pin the manifest digest outside this directory.

The primary result uses twelve alternating parent/candidate pairs of fresh Criterion invocations, each summarized by its raw-derived median. The estimator is the geometric mean candidate/parent ratio; its 95% interval is the percentile paired bootstrap over log ratios, with 20,000 resamples and seed 1646. Ratios below one favor the candidate; an interval crossing one is inconclusive. The two complete-suite context pairs are descriptive and are not pooled into the primary estimate.

All 704 original Criterion JSON records are retained, including fresh `base` copies. The exact unrounded result is in `analysis.json`; adverse and inconclusive observations remain present. This local macOS ARM64 ordinary wall-time replay does not establish the origin or cause of the historical CodSpeed alert.
""".encode()
MAX_MEMBER = 1024 * 1024
MAX_TOTAL = 32 * 1024 * 1024


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return {"sha256": digest(data), "bytes": len(data)}


def pretty(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def parse_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    require(isinstance(data, bytes) and len(data) <= MAX_TOTAL, "JSON size differs")
    return json.loads(data, object_pairs_hook=pairs, parse_constant=lambda _: (_ for _ in ()).throw(RuntimeError("non-finite JSON")))


def hash_string(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def read_regular(path, maximum=MAX_MEMBER):
    path = Path(path)
    before = path.lstat()
    require(path.is_absolute() and path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
        and not path.is_symlink() and before.st_size <= maximum, "noncanonical or oversized file")
    data = path.read_bytes()
    after = path.lstat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
        (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) and len(data) == before.st_size,
        "input changed during read")
    return data


def content_scan(data):
    text = data.decode("utf-8")
    require(re.search(r"(?:/(?:Users|home|private|tmp)/|file://|[a-z0-9]+-uv-dev(?:-[0-9]+)?|devbox-[0-9]|BEGIN [A-Z ]*PRIVATE KEY|github_pat_|gh[pousr]_[A-Za-z0-9]{20}|Bearer[ ]+[A-Za-z0-9])", text, re.I) is None,
        "private content in portable payload")


def runtime_rows():
    rows = []
    def row(label, role, kind, cases, block):
        return {"label": label, "role": role, "kind": kind, "expected_cases": list(cases), "block": block}
    for kind in ("list", "correctness"):
        for role in ("parent", "candidate"):
            rows.append(row(kind + "-" + role, role, kind, CASES if kind == "list" else (PRIMARY,), "admission"))
    for number in range(1, 13):
        order = ("parent", "candidate") if number % 2 else ("candidate", "parent")
        for index, role in enumerate(order, 1):
            rows.append(row(f"primary-{number:02}-{index}-{role}", role, "primary", (PRIMARY,), f"primary-{number:02}"))
    for index, role in enumerate(("parent", "candidate", "candidate", "parent"), 1):
        rows.append(row(f"context-{index:02}-{role}", role, "context", CASES, f"context-{(index + 1) // 2:02}"))
    return rows


def plan():
    return {"runtime_proposal": {"primary_case": PRIMARY, "expected_cases": list(CASES)}}


def expected_raw():
    return {f"raw/{row['label']}/{case}/{directory}/{name}"
        for row in runtime_rows() if row["kind"] in {"primary", "context"}
        for case in row["expected_cases"] for directory in ("new", "base") for name in RAW_NAMES}


def study_value(admission_sha256):
    require(hash_string(admission_sha256), "external final admission identity required")
    return {"schema": "uv-future.pr1646-portable-study.v1", "sources": SOURCES, "artifacts": ARTIFACTS,
        "fixtures": FIXTURES, "method": METHOD, "schedule": runtime_rows(),
        "final_admission": {"reader_sha256": READER_SHA, "admission_sha256": admission_sha256,
            "terminal_sha256": TERMINAL_SHA, "result_sha256": RESULT_SHA,
            "build_admission_sha256": BUILD_ADMISSION_SHA}}


def finite(value, *, positive=False):
    return type(value) in (int, float) and math.isfinite(value) and (value > 0 if positive else value >= 0)


def close(actual, expected):
    return type(actual) in (int, float) and math.isfinite(actual) and math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-8)


def percentile(values, fraction):
    ordered = sorted(values)
    rank = fraction * (len(ordered) - 1)
    lower = math.floor(rank)
    upper = math.ceil(rank)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (rank - lower)


def validate_samples(sample, estimates, benchmark, tukey, case):
    group, function, project = case.split("/")
    require(benchmark == {"group_id": group, "function_id": function, "value_str": project, "throughput": None,
        "full_id": case, "directory_name": case, "title": case}, "Criterion benchmark identity differs")
    require(isinstance(sample, dict) and set(sample) == {"sampling_mode", "iters", "times"}
        and sample["sampling_mode"] in {"Linear", "Flat"} and len(sample["iters"]) == len(sample["times"]) == 20
        and all(finite(item, positive=True) and item == int(item) for item in sample["iters"])
        and all(finite(item, positive=True) for item in sample["times"]), "Criterion sample is incomplete or invalid")
    counts, times = sample["iters"], sample["times"]
    first = counts[0]
    require(counts == ([first] * 20 if sample["sampling_mode"] == "Flat" else [first * index for index in range(1, 21)]), "Criterion iteration schedule differs")
    values = [elapsed / count for elapsed, count in zip(times, counts, strict=True)]
    require(isinstance(estimates, dict) and set(estimates) == {"mean", "median", "median_abs_dev", "slope", "std_dev"}
        and (estimates["slope"] is None) == (sample["sampling_mode"] == "Flat"), "Criterion estimates or sampling mode differ")
    for name, estimate in estimates.items():
        if estimate is None:
            require(name == "slope", "missing Criterion estimate")
            continue
        require(set(estimate) == {"confidence_interval", "point_estimate", "standard_error"}
            and finite(estimate["point_estimate"], positive=name in {"mean", "median", "slope"}) and finite(estimate["standard_error"]), "invalid Criterion estimate")
        interval = estimate["confidence_interval"]
        require(set(interval) == {"confidence_level", "lower_bound", "upper_bound"}
            and interval["confidence_level"] == 0.95 and finite(interval["lower_bound"])
            and finite(interval["upper_bound"]) and interval["lower_bound"] <= interval["upper_bound"], "invalid Criterion confidence interval")
    median = percentile(values, 0.5)
    require(close(estimates["median"]["point_estimate"], median), "Criterion median is not derived from raw per-operation samples")
    q1, q3 = percentile(values, 0.25), percentile(values, 0.75)
    iqr = q3 - q1
    fences = [q1 - 3 * iqr, q1 - 1.5 * iqr, q3 + 1.5 * iqr, q3 + 3 * iqr]
    require(isinstance(tukey, list) and len(tukey) == 4 and all(close(item, wanted) for item, wanted in zip(tukey, fences, strict=True)), "Criterion outlier fences differ")
    outliers = {name: 0 for name in ("low_severe", "low_mild", "ordinary", "high_mild", "high_severe")}
    for item in values:
        label = "low_severe" if item < fences[0] else "high_severe" if item > fences[3] else "low_mild" if item < fences[1] else "high_mild" if item > fences[2] else "ordinary"
        outliers[label] += 1
    mean = statistics.fmean(values)
    return {"case": case, "sampling_mode": sample["sampling_mode"], "sample_count": 20, "total_iterations": sum(counts),
        "total_measured_ns": sum(times), "median_ns": median, "mean_ns": mean, "standard_deviation_ns": statistics.stdev(values),
        "relative_standard_deviation": statistics.stdev(values) / mean, "q1_ns": q1, "q3_ns": q3, "min_ns": min(values), "max_ns": max(values),
        "outliers": outliers, "criterion_median_interval": estimates["median"]["confidence_interval"]}


def paired_analysis(measurements):
    rows = [row for row in runtime_rows() if row["kind"] == "primary"]
    require(len(rows) == 24 and len(measurements) == 28, "complete predeclared timing inventory required")
    ratios = []
    for index in range(0, len(rows), 2):
        pair = rows[index:index + 2]
        values = {}
        for row in pair:
            cases = measurements[row["label"]]["cases"]
            require(len(cases) == 1 and cases[0]["case"] == plan()["runtime_proposal"]["primary_case"], "primary case differs")
            values[row["role"]] = cases[0]["median_ns"]
        ratios.append({"pair": pair[0]["block"], "order": [row["role"] for row in pair], "parent_ns": values["parent"],
            "candidate_ns": values["candidate"], "ratio": values["candidate"] / values["parent"]})
    logs = [math.log(item["ratio"]) for item in ratios]
    randomizer = random.Random(1646)
    bootstrap = sorted(math.exp(statistics.fmean(randomizer.choices(logs, k=len(logs)))) for _ in range(20000))
    contexts = []
    context_rows = [row for row in runtime_rows() if row["kind"] == "context"]
    for index in (0, 2):
        pair = context_rows[index:index + 2]
        by_role = {row["role"]: {case["case"]: case["median_ns"] for case in measurements[row["label"]]["cases"]} for row in pair}
        contexts.append({"pair": pair[0]["block"], "order": [row["role"] for row in pair], "ratios": {
            case: by_role["candidate"][case] / by_role["parent"][case] for case in plan()["runtime_proposal"]["expected_cases"]}})
    return {"primary_pairs": ratios, "geometric_mean_ratio": math.exp(statistics.fmean(logs)),
        "paired_bootstrap": {"seed": 1646, "resamples": 20000, "confidence": 0.95, "lower": percentile(bootstrap, 0.025), "upper": percentile(bootstrap, 0.975)},
        "context_pairs": contexts, "historical_codspeed_attribution": "unresolved", "local_host_only": True}



def analyze_raw(files):
    require(set(files) == expected_raw() and len(files) == 704, "complete raw inventory required")
    require(sum(map(len, files.values())) <= MAX_TOTAL, "raw payload too large")
    measurements = {}
    for row in runtime_rows():
        if row["kind"] not in {"primary", "context"}:
            continue
        cases = []
        for case in row["expected_cases"]:
            for name in RAW_NAMES:
                require(files[f"raw/{row['label']}/{case}/new/{name}"] ==
                    files[f"raw/{row['label']}/{case}/base/{name}"], "fresh baseline copy differs")
            values = [parse_json(files[f"raw/{row['label']}/{case}/new/{name}"]) for name in RAW_NAMES]
            cases.append(validate_samples(*values, case))
        measurements[row["label"]] = {"cases": cases}
    require(sum(len(value["cases"]) for value in measurements.values()) == 88, "case inventory differs")
    return paired_analysis(measurements)


def admit_payload(payload, manifest):
    require(set(manifest) == {"schema", "payload"} and manifest["schema"] == SCHEMA, "manifest schema differs")
    wanted = expected_raw() | {"README.md", "analyze.py", "study.json", "analysis.json"}
    require(set(payload) == wanted and len(payload) == 708 and manifest["payload"] ==
        {name: identity(data) for name, data in sorted(payload.items())}, "exact allowlisted payload differs")
    require(sum(map(len, payload.values())) <= MAX_TOTAL, "portable payload too large")
    for name, data in payload.items():
        if name != "analyze.py":
            content_scan(data)
    study = parse_json(payload["study.json"])
    require(study == study_value(study["final_admission"]["admission_sha256"]), "study provenance differs")
    require(payload["README.md"] == README, "public explanation differs")
    analysis = analyze_raw({name: payload[name] for name in expected_raw()})
    require(parse_json(payload["analysis.json"]) == analysis, "saved analysis differs from complete raw data")
    return {"schema": "uv-future.pr1646-portable-admission.v1", "accepted": True,
        "sources": SOURCES, "method": METHOD, "final_admission": study["final_admission"],
        "analysis": analysis, "publication_authorized": False}


def admit_portable(bundle, expected_manifest_sha256):
    bundle = Path(bundle).resolve(strict=True)
    require(bundle.is_dir() and hash_string(expected_manifest_sha256), "external manifest pin required")
    manifest_data = read_regular(bundle / "manifest.json", MAX_TOTAL)
    require(digest(manifest_data) == expected_manifest_sha256, "manifest digest differs")
    manifest = parse_json(manifest_data)
    wanted = expected_raw() | {"README.md", "analyze.py", "study.json", "analysis.json", "manifest.json"}
    found = set()
    for directory, dirs, names in os.walk(bundle, followlinks=False):
        for name in dirs:
            path = Path(directory) / name
            require(stat.S_ISDIR(path.lstat().st_mode) and not path.is_symlink(), "unexpected directory entry")
        for name in names:
            path = Path(directory) / name
            relative = path.relative_to(bundle).as_posix()
            require(relative in wanted and len(found) < 709, "unexpected portable file")
            found.add(relative)
    require(found == wanted, "portable file inventory differs")
    payload = {name: read_regular(bundle / name) for name in sorted(wanted - {"manifest.json"})}
    require(payload["analyze.py"] == read_regular(Path(__file__).resolve()), "analyzer source differs")
    return admit_payload(payload, manifest) | {"manifest_sha256": expected_manifest_sha256}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    args = parser.parse_args()
    print(json.dumps(admit_portable(args.bundle, args.manifest_sha256), indent=2, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()

