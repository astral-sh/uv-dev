# PR1646 exact-source wheel-install replay

This evidence accompanies [PR1646](https://github.com/astral-sh/uv-dev/pull/1646) and reuses the real-wheel workload owned by [PR1477](https://github.com/astral-sh/uv-dev/pull/1477). The source pair, actual retained executable identities, fixture hashes, requested profile, observed Cargo profile, and complete invocation order are in `study.json`.

Run `uv run --no-project --no-config --offline --no-managed-python --no-python-downloads -- python -I -B analyze.py --bundle . --manifest-sha256 <externally-pinned-sha256>`. No product executable, network, or third-party Python package is needed for reanalysis. Pin the manifest digest outside this directory.

The primary result uses twelve alternating parent/candidate pairs of fresh Criterion invocations, each summarized by its raw-derived median. The estimator is the geometric mean candidate/parent ratio; its 95% interval is the percentile paired bootstrap over log ratios, with 20,000 resamples and seed 1646. Ratios below one favor the candidate; an interval crossing one is inconclusive. The two complete-suite context pairs are descriptive and are not pooled into the primary estimate.

All 704 original Criterion JSON records are retained, including fresh `base` copies. The exact unrounded result is in `analysis.json`; adverse and inconclusive observations remain present. This local macOS ARM64 ordinary wall-time replay does not establish the origin or cause of the historical CodSpeed alert.
