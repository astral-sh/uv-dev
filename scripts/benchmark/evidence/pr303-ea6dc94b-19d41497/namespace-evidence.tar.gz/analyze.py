"""Offline, exact-order reanalysis of the PR303 whole-uninstall evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import stat
import statistics
import types

SCHEMA = "uv-future.pr303-portable-manifest.v1"
STATIC_SHA = "1789439e5c3c9d467197216290b382420573ac5cf2320e6b68327e9a623c1aa6"
SCHEDULE_SHA = "6e22e30406e9e3f53a55b393059e40a3797518fbdf2f4c8ac2335214fb730cf2"
PAYLOAD = frozenset({"README.md", "analyze.py", "schedule.json", "samples.jsonl", "study.json", "analysis.json"})
MAX_MEMBER = 4 * 1024 * 1024
MAX_TOTAL = 32 * 1024 * 1024
ROLES = {"AB": ("parent", "candidate"), "BA": ("candidate", "parent")}
_schedule = None


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return {"sha256": digest(data), "bytes": len(data)}


def pretty(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def compact(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def parse_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    def finite_float(text):
        value = float(text)
        require(math.isfinite(value), "non-finite JSON")
        return value
    require(isinstance(data, bytes) and len(data) <= MAX_TOTAL, "JSON size differs")
    return json.loads(data, object_pairs_hook=pairs, parse_float=finite_float,
        parse_constant=lambda _: (_ for _ in ()).throw(RuntimeError("non-finite JSON")))


def hash_string(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None and value != "0" * 64


def valid_identity(value):
    return isinstance(value, dict) and set(value) == {"sha256", "bytes"} and hash_string(value["sha256"]) \
        and type(value["bytes"]) is int and value["bytes"] > 0


def read_regular(path, maximum=MAX_MEMBER):
    path = Path(path)
    before = path.lstat()
    require(path.is_absolute() and path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
        and not path.is_symlink() and 0 < before.st_size <= maximum, "noncanonical or oversized file")
    data = path.read_bytes()
    after = path.lstat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
        (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
        and len(data) == before.st_size, "input changed during read")
    return data


def content_scan(data):
    text = data.decode("utf-8")
    require(re.search(r"(?:/(?:Users|home|private|tmp)/|file://|[a-z0-9]+-uv-dev(?:-[0-9]+)?|devbox-[0-9]|BEGIN [A-Z ]*PRIVATE KEY|github_pat_|gh[pousr]_[A-Za-z0-9]{20}|Bearer[ ]+[A-Za-z0-9])", text, re.I) is None,
        "private content in portable payload")


def schedule():
    require(_schedule is not None, "schedule has not been admitted")
    return _schedule


def command_rows():
    rows = []
    for cell in schedule()["cells"]:
        for phase, key in (("warmup", "warmup_order"), ("measured", "measured_order")):
            for number, order in enumerate(cell[key], 1):
                pair = cell["endpoint"]["name"] + "/" + cell["cache_state"] + "/" + phase + "/" + str(number)
                for role in ROLES[order]:
                    rows.append({"pair": pair, "endpoint": cell["endpoint"]["name"],
                        "cache_state": cell["cache_state"], "phase": phase, "iteration": number,
                        "order": order, "role": role})
    if len(rows) != 720 or len({(item["pair"], item["role"]) for item in rows}) != 720:
        raise RuntimeError("paired schedule is not unique and complete")
    return rows


def estimates(s, rows):
    result = []
    for cell in json.loads(s.SCHEDULE_JSON.read_bytes())["cells"]:
        selected = [row for row in rows if row["row"]["endpoint"] == cell["endpoint"]["name"]
                    and row["row"]["cache_state"] == cell["cache_state"] and row["row"]["phase"] == "measured"]
        s.require(len(selected) == 30, "incomplete measured cell")
        pairs = []
        for index in range(0, 30, 2):
            left, right = selected[index:index + 2]
            s.require(left["row"]["pair"] == right["row"]["pair"] and left["row"]["role"] != right["row"]["role"]
                and left["before_logical_sha256"] == right["before_logical_sha256"]
                and left["expected_sha256"] == right["expected_sha256"], "measured pair input/work differs")
            values = {item["row"]["role"]: item["elapsed_ns"] for item in (left, right)}
            pairs.append({"pair": left["row"]["pair"], "order": left["row"]["order"], **values})
        differences = [(row["parent"] - row["candidate"]) / 1000000 for row in pairs]
        ratios = [row["candidate"] / row["parent"] for row in pairs]
        rng, diff_boot, ratio_boot = random.Random(2150), [], []
        for _ in range(10000):
            indices = [rng.randrange(15) for _ in range(15)]
            diff_boot.append(statistics.median(differences[i] for i in indices))
            ratio_boot.append(statistics.median(ratios[i] for i in indices))
        diff_boot.sort(); ratio_boot.sort()
        result.append({"endpoint": cell["endpoint"]["name"], "cache_state": cell["cache_state"], "pairs": pairs,
            "median_ms_saved": statistics.median(differences), "median_candidate_parent_ratio": statistics.median(ratios),
            "paired_bootstrap_95_ms": [diff_boot[249], diff_boot[9749]],
            "paired_bootstrap_95_ratio": [ratio_boot[249], ratio_boot[9749]], "resamples": 10000, "seed": 2150})
    return result


def admitted_schedule(data):
    global _schedule
    require(digest(data) == SCHEDULE_SHA, "predeclared schedule changed")
    value = parse_json(data)
    require(value["schema"] == "uv-future.legacy-namespace-paired-schedule.v1"
        and value["seed"] == 2150 and len(value["cells"]) == 20 and value["warmup_uninstalls"] == 120
        and value["measured_pairs"] == 300 and value["measured_uninstalls"] == 600
        and value["total_uninstalls"] == 720, "fixed schedule counts differ")
    _schedule = value
    return command_rows()


def command_labels(row):
    labels = ["identity-before"]
    if row["cache_state"] == "warm-interpreter-query":
        labels.append("warm-query")
    return labels + ["uninstall", "identity-after", "protected-health"]


def validate_study(study):
    require(isinstance(study, dict) and set(study) == {"schema", "static", "admission"}
        and study["schema"] == "uv-future.pr303-portable-study.v1"
        and digest(pretty(study["static"])) == STATIC_SHA, "source/build/fixture scope differs")
    admission = study["admission"]
    require(isinstance(admission, dict) and set(admission) == {"approval", "terminal", "result", "saved_admission"}
        and all(valid_identity(item) for item in admission.values())
        and len({item["sha256"] for item in admission.values()}) == 4, "actual external admission identities required")
    return study["static"]


def parse_samples(data, planned, static):
    require(data.endswith(b"\n") and b"\r" not in data, "sample JSONL framing differs")
    lines = data.splitlines()
    require(len(lines) == 720, "complete 720-sample projection required")
    templates = {item["name"]: item for item in static["fixtures"]["templates"]}
    result, commands, seen = [], 0, set()
    evidence_keys = {"sample_result", "intent", "before", "after", "cache_before", "commands"}
    for index, (line, row) in enumerate(zip(lines, planned, strict=True), 1):
        value = parse_json(line)
        require(set(value) == {"index", "row", "elapsed_ns", "before_logical_sha256", "expected_sha256", "evidence"}
            and type(value["index"]) is int and value["index"] == index and value["row"] == row
            and type(value["elapsed_ns"]) is int and 0 < value["elapsed_ns"] <= 61 * 1000000000,
            "sample order or exact native elapsed time differs")
        template = templates[row["endpoint"]]
        require(value["before_logical_sha256"] == template["logical_sha256"]
            and value["expected_sha256"] == template["expected_sha256"], "sample input/work identity differs")
        proof = value["evidence"]
        require(isinstance(proof, dict) and set(proof) == evidence_keys
            and all(valid_identity(proof[name]) for name in evidence_keys - {"commands"}), "sample evidence identity differs")
        records = proof["commands"]
        require(isinstance(records, list) and [item.get("label") for item in records] == command_labels(row)
            and all(set(item) == {"label", "sha256", "bytes"}
                    and valid_identity({key: item[key] for key in ("sha256", "bytes")}) for item in records),
            "sample command proof inventory differs")
        for item in records:
            require(item["sha256"] not in seen, "duplicate command proof")
            seen.add(item["sha256"])
        commands += len(records)
        result.append(value)
    require(commands == 3240 and len(seen) == 3240, "complete command-proof inventory required")
    for left, right in zip(result[::2], result[1::2], strict=True):
        require(left["row"]["pair"] == right["row"]["pair"]
            and (left["row"]["role"], right["row"]["role"]) == ROLES[left["row"]["order"]]
            and left["before_logical_sha256"] == right["before_logical_sha256"]
            and left["expected_sha256"] == right["expected_sha256"], "whole pair differs")
    return result


def analyze_samples(schedule_data, sample_data, static):
    planned = admitted_schedule(schedule_data)
    rows = parse_samples(sample_data, planned, static)
    context = types.SimpleNamespace(require=require, SCHEDULE_JSON=types.SimpleNamespace(read_bytes=lambda: schedule_data))
    return estimates(context, rows)


def admit_payload(payload, manifest):
    require(isinstance(manifest, dict) and set(manifest) == {"schema", "payload"}
        and manifest["schema"] == SCHEMA and set(payload) == PAYLOAD
        and isinstance(manifest["payload"], dict) and set(manifest["payload"]) == PAYLOAD
        and all(valid_identity(item) for item in manifest["payload"].values())
        and manifest["payload"] == {name: identity(data) for name, data in sorted(payload.items())},
        "exact allowlisted payload differs")
    require(all(isinstance(data, bytes) and 0 < len(data) <= MAX_MEMBER for data in payload.values())
        and sum(map(len, payload.values())) <= MAX_TOTAL, "portable byte bounds differ")
    for name, data in payload.items():
        if name != "analyze.py":
            content_scan(data)
    static = validate_study(parse_json(payload["study.json"]))
    require(identity(payload["README.md"]) == static["readme"], "public explanation differs")
    analysis = analyze_samples(payload["schedule.json"], payload["samples.jsonl"], static)
    require(parse_json(payload["analysis.json"]) == analysis and len(analysis) == 20,
        "saved pointwise analysis differs from complete raw data")
    return {"schema": "uv-future.pr303-portable-admission.v1", "accepted": True,
        "study": parse_json(payload["study.json"]), "analysis": analysis, "publication_authorized": False}


def admit_portable(bundle, expected_manifest_sha256):
    bundle = Path(os.path.abspath(bundle))
    require(bundle.is_absolute() and bundle.resolve(strict=True) == bundle and bundle.is_dir()
        and not bundle.is_symlink() and hash_string(expected_manifest_sha256), "external manifest pin required")
    require({item.name for item in bundle.iterdir()} == PAYLOAD | {"manifest.json"}, "portable file inventory differs")
    manifest_data = read_regular(bundle / "manifest.json")
    require(digest(manifest_data) == expected_manifest_sha256, "manifest digest differs")
    payload = {name: read_regular(bundle / name) for name in sorted(PAYLOAD)}
    require(payload["analyze.py"] == read_regular(Path(__file__).resolve()), "analyzer source differs")
    return admit_payload(payload, parse_json(manifest_data)) | {"manifest_sha256": expected_manifest_sha256}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    args = parser.parse_args()
    print(json.dumps(admit_portable(args.bundle, args.manifest_sha256), indent=2, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
