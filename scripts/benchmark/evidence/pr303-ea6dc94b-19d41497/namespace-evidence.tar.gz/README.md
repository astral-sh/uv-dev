# Legacy egg namespace whole-command evidence

This bundle records the complete-uninstall comparison for [uv-dev#303](https://github.com/astral-sh/uv-dev/pull/303). The optimized sources are `ea6dc94b6f23` and `19d414971b5b`: their lockfile and benchmark setup are identical, and their uninstall implementation diff is byte-identical to the `94ac9f5f3369` → `a4b71961e502` review pair. The final review-head change is test-only. `study.json` records the exact commits, trees, source-diff hashes, retained executable identities, requested and observed Cargo profiles, and authentic fixture identities.

Pin the SHA-256 of `manifest.json` outside the extracted directory, then run:

```sh
uv run --no-project --no-config --offline --no-managed-python --no-python-downloads -- python -I -B analyze.py --bundle . --manifest-sha256 <externally-pinned-sha256>
```

No product executable, network access, or third-party Python package is needed for reanalysis. The analyzer requires every member and byte in the manifest, all 720 ordered raw timing projections, the original shuffled AB/BA schedule, and all 20 unrounded estimates. Private process and filesystem qualification records are represented by content digests; portable reanalysis does not rerun those checks.

Each cold/warm endpoint uses 15 complete measured parent/candidate pairs after three warmup pairs. The point estimates are the median candidate/parent ratio and median paired milliseconds saved. The pointwise 95% intervals use the predeclared paired bootstrap with 10,000 resamples and seed 2150. Ratios below one favor the candidate; an interval crossing one is inconclusive. All predeclared endpoints, including small-input and recorded-file/modern-wheel bypass controls, remain in `analysis.json` regardless of outcome.

The clock covers the complete successful `uv pip uninstall` process from immediately before creation through its first native reap. Fixture setup, interpreter-cache warming, postflight checks, process-group cleanup, and evidence writing are outside the timed interval. The original #303 filter-only microbenchmark is separate historical evidence, not a whole-command result from this source pair. This local macOS ARM64 study does not establish native-Windows performance or a universal uninstall speedup.
