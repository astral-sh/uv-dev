"""Strict raw-record admission for the unchanged frozen PR244 estimator."""

from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path

HERE = Path(__file__).resolve().parent
V1_SHA256 = "004c7e1300cc28bfded68e8cbdfdbbd0f67b99bede35eb0d1e59ff401e7d2685"


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load frozen validator source: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def integer(value: object, label: str, minimum: int, maximum: int | None = None) -> None:
    if type(value) is not int or value < minimum or (maximum is not None and value > maximum):
        raise ValueError(f"Invalid exact integer: {label}")


def digest(value: object, label: str) -> None:
    if type(value) is not str or len(value) != 64 or any(char not in "0123456789abcdef" for char in value):
        raise ValueError(f"Invalid exact SHA-256: {label}")


def identity(value: dict) -> None:
    for side in ["base", "head"]:
        for key in ["executable_sha256", "build_manifest_sha256"]:
            digest(value[side][key], f"identity.{side}.{key}")
    for key in ["matching_admission_bytes_sha256", "execution_admission_sha256"]:
        digest(value[key], f"identity.{key}")


def observations(data: dict) -> None:
    identity(data["identity"])
    if type(data["contrasts"]) is not list:
        raise ValueError("Contrasts must be a raw ordered list")
    for entry in data["contrasts"]:
        integer(entry["iterations"], "contrast.iterations", 1, 1_048_576)
        if type(entry["blocks"]) is not list:
            raise ValueError("Blocks must be a raw ordered list")
        for block in entry["blocks"]:
            integer(block["index"], "block.index", 0, 23)
            for sample in block["samples"].values():
                integer(sample["process_sequence"], "sample.process_sequence", 0, 47)
                integer(sample["iterations"], "sample.iterations", 1, 1_048_576)
                integer(sample["completed_iterations"], "sample.completed_iterations", 1, 1_048_576)
                integer(sample["elapsed_ns"], "sample.elapsed_ns", 1_000_000, 10_000_000_000)
                integer(sample["groups_per_iteration"], "sample.groups_per_iteration", 0)
                integer(sample["requirements_per_iteration"], "sample.requirements_per_iteration", 0)
                integer(sample["exit_status"], "sample.exit_status", 0, 0)


def fixed_design(data: dict, expected: list[tuple[str, str]]) -> None:
    if type(data["contrasts"]) is not list:
        raise ValueError("Fixed design contrasts must be a raw ordered list")
    raw_keys = [(item["case"], item["clock"]) for item in data["contrasts"]]
    if raw_keys != expected:
        raise ValueError("Fixed design must contain exactly the 12 prescribed contrasts in order")
    identity(data["identity"])
    digest(data["aa_sha256"], "design.aa_sha256")
    if data.get("selection_uses_ab_observations") is not False:
        raise ValueError("Fixed design must declare no A/B-based selection")
    for item in data["contrasts"]:
        integer(item["iterations"], "design.iterations", 1, 1_048_576)
        count = item["ab_pairs"]
        if count is not None and (type(count) is not int or count not in [12, 24]):
            raise ValueError("Invalid exact planned paired count")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["choose", "report"])
    parser.add_argument("observations", type=Path)
    parser.add_argument("--design", type=Path)
    args = parser.parse_args()
    # Bootstrap only the exact previously retained source; it verifies the
    # unchanged production-plan and statistical-analyzer inputs before use.
    import hashlib

    v1_path = HERE / "analyze_pairs_preflight.py"
    if v1_path.is_symlink() or not v1_path.is_file() or v1_path.stat().st_size > 1024 * 1024 or hashlib.sha256(v1_path.read_bytes()).hexdigest() != V1_SHA256:
        raise ValueError("Frozen v1 preflight identity mismatch")
    v1 = load(v1_path, "pr244_frozen_preflight_v1")
    analyzer_path = v1.FROZEN / "analyze_pairs.py"
    v1.verified(analyzer_path, v1.ANALYZER_SHA256)
    v1.verified(v1.FROZEN / "plan.json", v1.PLAN_SHA256)
    analyzer = load(analyzer_path, "pr244_frozen_pair_analyzer_v2")
    if analyzer.contrasts(analyzer.read(v1.FROZEN / "plan.json")) != v1.EXPECTED:
        raise ValueError("Frozen plan does not contain the prescribed 12 contrasts")
    observations(analyzer.read(args.observations))
    if args.mode == "report":
        if args.design is None:
            raise ValueError("A/B requires the previously sealed A/A design")
        fixed_design(analyzer.read(args.design), v1.EXPECTED)
    analyzer.main()


if __name__ == "__main__":
    main()
