"""Validate retained PR244 process-pair records and print pointwise log-ratio CIs."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path

HERE = Path(__file__).parent
T975 = {12: 2.200985160082949, 24: 2.0686576104190406}


def read(path: Path) -> dict:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 16 * 1024 * 1024:
        raise ValueError(f"Invalid bounded ordinary input: {path}")
    return json.loads(path.read_bytes())


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def interval(values: list[float]) -> dict:
    count = len(values)
    if count not in T975 or not all(math.isfinite(value) for value in values):
        raise ValueError("Unexpected complete paired sample count")
    mean = statistics.mean(values)
    deviation = statistics.stdev(values)
    half_width = T975[count] * deviation / math.sqrt(count)
    return {"pairs": count, "mean_log_ratio": mean, "paired_log_sd": deviation, "log_half_width": half_width, "ratio": math.exp(mean), "pointwise_95_ci": [math.exp(mean - half_width), math.exp(mean + half_width)]}


def contrasts(plan: dict) -> list[tuple[str, str]]:
    return [(case, clock) for case in plan["statistics"]["first_pass_case_ids"] for clock in plan["statistics"]["clock_names"]]


def validate_common(data: dict, plan: dict, phase: str) -> None:
    if data.get("schema") != "uv-pr244-ordered-process-pairs-v1" or data.get("phase") != phase:
        raise ValueError("Unexpected observation schema/phase")
    if data.get("plan_sha256") != digest(HERE / "plan.json") or data.get("fixture_sha256") != plan["fixtures"]["fixture_sha256"]:
        raise ValueError("Plan/fixture identity mismatch")
    identity = data["identity"]
    for side in ["base", "head"]:
        binding = identity[side]
        if binding["overlaid_tree"] != plan["source_pair"][side]["overlaid_tree"]:
            raise ValueError("Source-tree mismatch")
        for key in ["executable_sha256", "build_manifest_sha256"]:
            if len(binding[key]) != 64 or any(char not in "0123456789abcdef" for char in binding[key]):
                raise ValueError("Missing sealed executable/build identity")
    if not identity.get("matching_admission_bytes_sha256") or not identity.get("execution_admission_sha256"):
        raise ValueError("Missing behavior/execution admission")


def logs(entry: dict, identity: dict, phase: str, count: int, fixture: str) -> list[float]:
    blocks = entry["blocks"]
    if len(blocks) != count or count not in T975:
        raise ValueError("Incomplete or unplanned paired blocks")
    values = []
    for index, block in enumerate(blocks):
        order = ["A", "B"] if index % 2 == 0 else ["B", "A"]
        if block["index"] != index or block["observed_order"] != order:
            raise ValueError("Missing fixed balanced temporal order")
        samples = block["samples"]
        if set(samples) != {"A", "B"}:
            raise ValueError("Duplicate/missing arm")
        for position, arm in enumerate(order):
            sample = samples[arm]
            side = "base" if phase == "aa" or arm == "A" else "head"
            binding = identity[side]
            if sample["process_sequence"] != 2 * index + position:
                raise ValueError("Process order mismatch")
            if sample["executable_sha256"] != binding["executable_sha256"] or sample["overlaid_tree"] != binding["overlaid_tree"]:
                raise ValueError("Per-process source/executable mismatch")
            if sample["schema"] != "uv-pr244-api-sample-v1" or sample["fixture_sha256"] != fixture or sample["case"] != entry["case"] or sample["clock"] != entry["clock"]:
                raise ValueError("Per-process workload mismatch")
            if sample["iterations"] != entry["iterations"] or not 1 <= sample["iterations"] <= 1_048_576 or not 1_000_000 <= sample["elapsed_ns"] <= 10_000_000_000:
                raise ValueError("Invalid fixed iteration count/sample duration")
            if sample["completed_iterations"] != sample["iterations"] or sample.get("exit_status") != 0:
                raise ValueError("Invalid behavior/checksum/exit status")
        for key in ["iterations", "groups_per_iteration", "requirements_per_iteration", "completed_iterations"]:
            if samples["A"][key] != samples["B"][key]:
                raise ValueError("Unequal semantic work")
        values.append(math.log(samples["B"]["elapsed_ns"] / samples["A"]["elapsed_ns"]))
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["choose", "report"])
    parser.add_argument("observations", type=Path)
    parser.add_argument("--design", type=Path)
    args = parser.parse_args()
    plan = read(HERE / "plan.json")
    data = read(args.observations)
    phase = "aa" if args.mode == "choose" else "ab"
    validate_common(data, plan, phase)
    expected = contrasts(plan)
    entries = {(entry["case"], entry["clock"]): entry for entry in data["contrasts"]}
    if len(entries) != len(data["contrasts"]):
        raise ValueError("Duplicate contrast")
    results = []
    if phase == "aa":
        if args.design is not None or list(entries) != expected:
            raise ValueError("A/A must contain the complete prespecified contrast order")
        for key, entry in entries.items():
            stats = interval(logs(entry, data["identity"], phase, 12, data["fixture_sha256"]))
            target = math.log(1.025)
            stable = abs(stats["mean_log_ratio"]) <= math.log(1.01)
            projected = T975[24] * stats["paired_log_sd"] / math.sqrt(24)
            count = 12 if stable and stats["log_half_width"] <= target else 24 if stable and projected <= target else None
            results.append({"case": key[0], "clock": key[1], "iterations": entry["iterations"], "aa": stats, "ab_pairs": count, "status": "admitted" if count else "inconclusive-aa"})
        output = {"schema": "uv-pr244-fixed-design-v1", "plan_sha256": data["plan_sha256"], "aa_sha256": digest(args.observations), "identity": data["identity"], "contrasts": results, "selection_uses_ab_observations": False}
    else:
        if args.design is None:
            raise ValueError("A/B requires the previously sealed A/A design")
        design = read(args.design)
        if design["schema"] != "uv-pr244-fixed-design-v1" or design["plan_sha256"] != data["plan_sha256"] or design["identity"] != data["identity"] or data.get("design_sha256") != digest(args.design):
            raise ValueError("Fixed pre-A/B design identity mismatch")
        selected = {(item["case"], item["clock"]): item for item in design["contrasts"]}
        if list(selected) != expected or list(entries) != [key for key in expected if selected[key]["ab_pairs"] is not None]:
            raise ValueError("Missing, extra, or reordered planned contrast")
        for key in expected:
            choice = selected[key]
            if choice["ab_pairs"] is None:
                results.append({"case": key[0], "clock": key[1], "status": "inconclusive-aa"})
                continue
            entry = entries[key]
            if entry["iterations"] != choice["iterations"]:
                raise ValueError("Iteration count changed after A/A")
            stats = interval(logs(entry, data["identity"], phase, choice["ab_pairs"], data["fixture_sha256"]))
            low, high = stats["pointwise_95_ci"]
            label = "improvement-at-least-5pct" if high < 0.95 else "regression-at-least-5pct" if low > 1.05 else "within-plus-or-minus-5pct" if low >= 0.95 and high <= 1.05 else "inconclusive"
            results.append({"case": key[0], "clock": key[1], "status": label, **stats})
        output = {"schema": "uv-pr244-paired-report-v1", "plan_sha256": data["plan_sha256"], "design_sha256": digest(args.design), "observations_sha256": digest(args.observations), "identity": data["identity"], "ratio_direction": "head/base", "interval_scope": "pointwise, not simultaneous", "statistical_unit": "independently ordered two-process paired block", "contrasts": results, "whole_command_claim": False}
    print(json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()
