# Installed-index benchmark evidence

This bundle contains the complete retained statistical evidence for
[uv-dev#1734](https://github.com/astral-sh/uv-dev/pull/1734). The measured baseline is
`36e89bca95a8ddb88440f848c45ecf5085d1f74a`; the measured candidate is
`4623a328071784425501a39626beef978a5b1d3f`. Their seven benchmark-overlay files are identical,
and their production diff matches #1734. The later lint-corrected #1739 owner head was not measured.

`samples.json` retains the original ordered 632 processes and 316 pairs: the complete library
screen, eight paired-library endpoints, and eighteen fresh-process `uv pip list` endpoints.
The screen has 72 descriptive rows and no process-round confidence interval. The paired studies
use twelve rounds, 100,000 resamples, seed `20260911`, and pointwise 95% intervals. Library
confirmation retains each process's forty original Criterion groups; whole-command confirmation
retains one integer wall time per process. The unchanged estimator resamples matched rounds
together, then each arm's recorded groups, and reports the pooled normalized-group median.
The two `ablation-*` library endpoints compare the measured candidate's serial and default
settings. The CLI serial endpoints compare baseline and candidate at the same serial setting.

All results are retained, including the small present/500 library regression
(`1.0100 [1.0022, 1.0135]`) and the inconclusive small-environment, serial, and Jupyter command
controls. The warm Linux `profiling` measurements do not establish a cold-cache or general
small-environment speedup, an optimal cutoff, or a family-wide confidence guarantee.

`study.json` records source, tree, build, workload, schedule, and hash-only qualification
identities. The original archive contains every timed observation and retained process record,
but not the original fixture trees, fifteen fixture read-state files, executables, source
worktrees, or interpreter-query caches. Their identities and historical checks are bound to
the original receipts; offline statistical reanalysis is not a new observation of that host.
The 36 untimed command preflights are qualification evidence, not timing samples.

Use a separately obtained `manifest.json` SHA-256 to verify the exact seven-file bundle and
recompute every unrounded result with a local Python 3.12 or newer:

```console
uv run --no-project --no-config --offline --no-python-downloads -- python -I -B analyze.py --bundle . --manifest-sha256 <SHA256>
```

The analyzer uses only the Python standard library. The manifest binds the six payload files;
an external manifest hash provides the integrity anchor. No product binary or package is executed
by this reanalysis.
