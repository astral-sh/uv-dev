"""Offline exact-order reanalysis of the PR1734 installed-index measurements."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import statistics
import types
from typing import Any

SCHEMA = "uv-future.pr1734-portable-manifest.v1"
STUDY_SHA = "a9abfc4490b793f7a12b9cedc31abc791ccc660025af59450b043b0b198837c4"
SAMPLES_SHA = "d30c3e34277d114b92ca14922909e416f76c26943af04155f10149acd909968e"
ANALYSIS_SHA = "9a28285da80a03f61fb9bb6744dad5722954d9be2cf0f2fdfdf27fa4099c767b"
ESTIMATOR_SHA = "2adb862c2e8ab839921e1510e8215e5195f19bcf8745834ff86f05fc02cbe050"
ESTIMATOR_ARGS = {"resamples": 100000, "seed": 20260911, "confidence": 0.95, "expected_process_rounds": 12}
PAYLOAD = frozenset({"README.md", "study.json", "samples.json", "analysis.json", "estimator.py", "analyze.py"})
MAX_MEMBER = 4 * 1024 * 1024
MAX_TOTAL = 32 * 1024 * 1024
SOURCE_PAIR = {"base": ("36e89bca95a8ddb88440f848c45ecf5085d1f74a", "9807831e32cdb758b9a92e759015fdb4a5e791be"),
    "candidate": ("4623a328071784425501a39626beef978a5b1d3f", "9af9fcd4f34590d91c6efe880e1b3b4ae50d15a4")}
PHASES = ("screen", "confirmation", "cli")
COUNTS = (50, 500, 1023, 1024, 1025, 2000)
LAYOUTS = ("missing", "present", "mixed")
PAIR_ORDERS = ("AB", "BA", "BA", "AB", "AB", "BA", "BA", "AB", "AB", "BA", "BA", "AB")
PHASE_COUNTS = {"screen": (8, 4, 72), "confirmation": (192, 96, 8), "cli": (432, 216, 18)}
SCREEN_FIELDS = frozenset({"endpoint", "benchmark", "method", "control_median_ns", "candidate_median_ns",
    "candidate_control_ratio", "candidate_minus_control_ns", "process_provenance"})
RESULT_FIELDS = frozenset({"endpoint", "input_kind", "method", "confidence_level", "resamples", "seed",
    "process_rounds", "sample_groups_per_round", "control_median_ns", "control_median_ci_ns",
    "candidate_median_ns", "candidate_median_ci_ns", "candidate_control_ratio", "candidate_control_ratio_ci",
    "candidate_minus_control_ns", "candidate_minus_control_ci_ns", "per_round", "paired_runs"})


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return {"sha256": digest(data), "bytes": len(data)}


def pretty(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def parse_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    def finite_float(text):
        value = float(text)
        require(math.isfinite(value), "non-finite JSON")
        return value
    require(isinstance(data, bytes) and len(data) <= MAX_TOTAL, "JSON size differs")
    return json.loads(data, object_pairs_hook=pairs, parse_float=finite_float,
        parse_constant=lambda _: (_ for _ in ()).throw(RuntimeError("non-finite JSON")))


def hash_string(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None and value != "0" * 64


def valid_identity(value):
    return isinstance(value, dict) and set(value) == {"sha256", "bytes"} and hash_string(value["sha256"]) \
        and type(value["bytes"]) is int and value["bytes"] > 0


def read_regular(path, maximum=MAX_MEMBER):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path, "noncanonical file")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(descriptor)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= maximum, "nonregular or oversized file")
        chunks, remaining = [], before.st_size
        while remaining:
            chunk = os.read(descriptor, min(remaining, 1024 * 1024))
            require(chunk, "short file")
            chunks.append(chunk)
            remaining -= len(chunk)
        require(os.read(descriptor, 1) == b"", "file grew")
        after = os.fstat(descriptor)
        named = path.lstat()
        fields = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
        require(fields(before) == fields(after) == fields(named), "input changed during read")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def content_scan(data):
    text = data.decode("utf-8")
    require(re.search(r"(?:/(?:Users|home|private|tmp)/|file://|[a-z0-9]+-uv-dev(?:-[0-9]+)?|devbox-[0-9]|BEGIN [A-Z ]*PRIVATE KEY|github_pat_|gh[pousr]_[A-Za-z0-9]{20}|Bearer[ ]+[A-Za-z0-9])", text, re.I) is None,
        "private content in portable payload")


def all_rows() -> list[str]:
    return [
        f"installed_package_sidecars/{layout}/{count}"
        for layout in LAYOUTS
        for count in COUNTS
    ]


def role(source: str, width: int | None) -> dict[str, Any]:
    return {"source": source, "width": width}


def endpoint(
    identifier: str, rows: list[str], control: dict[str, Any], candidate: dict[str, Any]
) -> dict[str, Any]:
    return {"id": identifier, "benchmarks": rows, "A": control, "B": candidate}


def expected_endpoints(phase: str) -> list[dict[str, Any]]:
    if phase == "screen":
        return [
            endpoint(
                f"width-{width if width is not None else 'default'}",
                all_rows(),
                role("base", width),
                role("candidate", width),
            )
            for width in (None, 1, 4, 16)
        ]
    require(phase == "confirmation", f"unknown phase: {phase}")
    result = [
        endpoint(
            f"large-{layout}",
            [f"installed_package_sidecars/{layout}/2000"],
            role("base", None),
            role("candidate", None),
        )
        for layout in LAYOUTS
    ]
    result.extend(
        [
            endpoint(
                "ordinary-present",
                ["installed_package_sidecars/present/500"],
                role("base", None),
                role("candidate", None),
            ),
            endpoint(
                "boundary-missing",
                ["installed_package_sidecars/missing/1024"],
                role("base", None),
                role("candidate", None),
            ),
            endpoint(
                "boundary-present",
                ["installed_package_sidecars/present/1024"],
                role("base", None),
                role("candidate", None),
            ),
            endpoint(
                "ablation-missing",
                ["installed_package_sidecars/missing/2000"],
                role("candidate", 1),
                role("candidate", None),
            ),
            endpoint(
                "ablation-present",
                ["installed_package_sidecars/present/2000"],
                role("candidate", 1),
                role("candidate", None),
            ),
        ]
    )
    return result


def criterion_settings(phase: str) -> dict[str, Any]:
    if phase == "screen":
        return {
            "sample_groups": 10,
            "warmup_seconds": 1,
            "measurement_seconds": 2,
            "rounds": 1,
            "baseline": "screen",
        }
    return {
        "sample_groups": 40,
        "warmup_seconds": 2,
        "measurement_seconds": 5,
        "rounds": 12,
        "baseline": "confirmation",
    }


def schedule(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    endpoints = manifest["endpoints"]
    result = []
    for block in range(1, manifest["criterion"]["rounds"] + 1):
        offset = (block - 1) % len(endpoints)
        order = PAIR_ORDERS[block - 1]
        for current in endpoints[offset:] + endpoints[:offset]:
            result.append({"block": block, "endpoint": current["id"], "order": order})
    require(
        len({(item["block"], item["endpoint"]) for item in result}) == len(result),
        "duplicate logical pair",
    )
    return result


def expected_cli_endpoints() -> list[dict[str, Any]]:
    result = [
        {
            "id": f"{layout}-{count}-default",
            "fixture": f"{layout}-{count}",
            "width": None,
        }
        for layout in ("missing", "present", "mixed")
        for count in (1023, 1024, 1025, 2000)
    ]
    result.extend(
        {"id": f"{layout}-500-default", "fixture": f"{layout}-500", "width": None}
        for layout in ("missing", "present")
    )
    result.extend(
        {"id": f"{layout}-2000-serial", "fixture": f"{layout}-2000", "width": 1}
        for layout in ("missing", "present")
    )
    result.extend(
        {"id": f"jupyter-{label}", "fixture": "jupyter", "width": width}
        for label, width in (("default", None), ("serial", 1))
    )
    return result


def describe(control: list[float], candidate: list[float]) -> dict[str, Any]:
    a, b = statistics.median(control), statistics.median(candidate)
    return {
        "method": "descriptive medians from one process per source; no process-round interval",
        "control_median_ns": a,
        "candidate_median_ns": b,
        "candidate_control_ratio": b / a,
        "candidate_minus_control_ns": b - a,
    }


def numeric(value, positive=False):
    return type(value) in (int, float) and math.isfinite(value) and (not positive or value > 0)


def exact_fields(value, fields, message):
    require(type(value) is dict and set(value) == set(fields), message)


def validate_study(data):
    require(digest(data) == STUDY_SHA, "fixed study changed")
    value = parse_json(data)
    exact_fields(value, ("schema", "source", "build", "method", "phases", "workloads", "qualification", "historical", "limitations", "readme"),
        "study schema differs")
    require(value["schema"] == "uv-future.pr1734-portable-study.v1"
        and {role: (item["head"], item["tree"]) for role, item in value["source"]["pair"].items()} == SOURCE_PAIR,
        "measured source pair differs")
    method = value["method"]
    exact_fields(method, ("arguments", "estimator", "interval_scope", "timed_processes", "pairs", "untimed_preflights",
        "screen_rows", "paired_library_endpoints", "whole_command_endpoints", "replacements"), "method fields differ")
    arguments = method["arguments"]
    exact_fields(arguments, ESTIMATOR_ARGS, "method arguments differ")
    require(all(type(arguments[key]) is int for key in ("resamples", "seed", "expected_process_rounds"))
        and type(arguments["confidence"]) is float and arguments == ESTIMATOR_ARGS
        and valid_identity(method["estimator"])
        and method["estimator"] == {"sha256": ESTIMATOR_SHA, "bytes": 8313}
        and method["interval_scope"] == "pointwise", "estimator differs")
    counts = {"timed_processes": 632, "pairs": 316, "untimed_preflights": 36, "screen_rows": 72,
        "paired_library_endpoints": 8, "whole_command_endpoints": 18, "replacements": 0}
    require(all(type(method[key]) is int and method[key] == expected for key, expected in counts.items()), "study counts differ")
    phases = value["phases"]
    require(type(phases) is list and [item["phase"] for item in phases] == list(PHASES), "phase inventory differs")
    for phase in phases:
        exact_fields(phase, ("phase", "criterion", "endpoints", "schedule", "original_manifest", "original_index", "original_analysis"),
            "phase fields differ")
        name = phase["phase"]
        endpoints = expected_cli_endpoints() if name == "cli" else expected_endpoints(name)
        settings = {"rounds": 12} if name == "cli" else criterion_settings(name)
        require(pretty(phase["endpoints"]) == pretty(endpoints) and pretty(phase["criterion"]) == pretty(settings)
            and pretty(phase["schedule"]) == pretty(schedule(phase))
            and len(phase["schedule"]) == PHASE_COUNTS[name][1]
            and all(valid_identity(phase[key]) for key in ("original_manifest", "original_index", "original_analysis")),
            "predeclared phase differs")
    qualification = value["qualification"]
    require(type(qualification) is list and len(qualification) == 36, "qualification inventory differs")
    for index, item in enumerate(qualification):
        endpoint = phases[2]["endpoints"][index // 2]
        role = ("base", "candidate")[index % 2]
        exact_fields(item, ("endpoint", "arm", "source_role", "source_head", "source_tree", "width", "fixture",
            "graph_sha256", "original_record", "stdout_identity", "stderr_identity"), "qualification fields differ")
        require(item["endpoint"] == endpoint["id"] and item["arm"] == ("A", "B")[index % 2]
            and item["source_role"] == role and (item["source_head"], item["source_tree"]) == SOURCE_PAIR[role]
            and item["width"] == endpoint["width"] and (item["width"] is None or type(item["width"]) is int)
            and item["fixture"] == endpoint["fixture"] and hash_string(item["graph_sha256"])
            and all(valid_identity(item[key]) for key in ("original_record", "stdout_identity", "stderr_identity")),
            "qualification identity differs")
    require(valid_identity(value["readme"]), "README identity differs")
    return value


def validate_samples(value, study):
    require(type(value) is list and len(value) == 632, "complete 632-process projection required")
    planned = [(phase, pair, arm) for phase in study["phases"] for pair in phase["schedule"] for arm in pair["order"]]
    records, samples = set(), set()
    base_fields = {"index", "phase", "block", "endpoint", "order", "arm", "source_role", "width", "original_record"}
    for number, (item, (phase, pair, arm)) in enumerate(zip(value, planned, strict=True)):
        name = phase["phase"]
        endpoint = next(endpoint for endpoint in phase["endpoints"] if endpoint["id"] == pair["endpoint"])
        selection = {"source": "base" if arm == "A" else "candidate", "width": endpoint["width"]} if name == "cli" else endpoint[arm]
        exact_fields(item, base_fields | ({"elapsed_ns"} if name == "cli" else {"rows"}), "sample fields differ")
        require(type(item["index"]) is int and item["index"] == number and item["phase"] == name
            and type(item["block"]) is int and {key: item[key] for key in pair} == pair and item["arm"] == arm
            and item["source_role"] == selection["source"] and item["width"] == selection["width"]
            and (item["width"] is None or type(item["width"]) is int)
            and valid_identity(item["original_record"]) and item["original_record"]["sha256"] not in records,
            "sample order, role, or identity differs")
        records.add(item["original_record"]["sha256"])
        if name == "cli":
            require(type(item["elapsed_ns"]) is int and 0 < item["elapsed_ns"] <= 120000000000, "native wall time differs")
            continue
        require(type(item["rows"]) is list and [row["benchmark"] for row in item["rows"]] == endpoint["benchmarks"],
            "complete Criterion row inventory differs")
        for row in item["rows"]:
            exact_fields(row, ("benchmark", "sample", "sample_identity", "estimates_identity", "metadata_identity"),
                "Criterion row fields differ")
            require(all(valid_identity(row[key]) for key in ("sample_identity", "estimates_identity", "metadata_identity"))
                and row["sample_identity"]["sha256"] not in samples, "Criterion artifact identity differs")
            samples.add(row["sample_identity"]["sha256"])
            original = row["sample"]
            exact_fields(original, ("iters", "sampling_mode", "times"), "Criterion sample fields differ")
            groups = phase["criterion"]["sample_groups"]
            require(original["sampling_mode"] in ("Linear", "Flat") and type(original["iters"]) is list and type(original["times"]) is list
                and len(original["iters"]) == len(original["times"]) == groups
                and all(numeric(x, positive=True) for x in original["iters"] + original["times"])
                and all(numeric(elapsed / count, positive=True) for count, elapsed in zip(original["iters"], original["times"], strict=True)),
                "original Criterion numeric arrays differ")
    require(len(records) == 632 and len(samples) == 336, "complete source-record inventory differs")
    return value


def load_estimator(source):
    require(identity(source) == {"sha256": ESTIMATOR_SHA, "bytes": 8313}, "unchanged estimator required")
    module = types.ModuleType("verified_pr1734_estimator")
    module.__file__ = "verified:estimator.py"
    exec(compile(source, module.__file__, "exec"), module.__dict__)
    return module


def recompute(study, rows, estimator_source):
    estimator = load_estimator(estimator_source)
    estimator.self_test()
    indexed = {(item["phase"], item["endpoint"], item["block"], item["arm"]): item for item in rows}
    require(len(indexed) == len(rows), "duplicate process key")
    result = {name: [] for name in PHASES}
    for phase in study["phases"]:
        name = phase["phase"]
        for endpoint in phase["endpoints"]:
            if name == "screen":
                a, b = (indexed[name, endpoint["id"], 1, arm] for arm in ("A", "B"))
                for index, benchmark in enumerate(endpoint["benchmarks"]):
                    control, candidate = (estimator.normalized_samples(item["rows"][index]["sample"]) for item in (a, b))
                    result[name].append({"endpoint": endpoint["id"], "benchmark": benchmark, **describe(control, candidate),
                        "process_provenance": {"A": a["original_record"], "B": b["original_record"]}})
                continue
            control, candidate, provenance = [], [], []
            for block in range(1, 13):
                a, b = (indexed[name, endpoint["id"], block, arm] for arm in ("A", "B"))
                for collection, item in ((control, a), (candidate, b)):
                    collection.append([float(item["elapsed_ns"])] if name == "cli" else estimator.normalized_samples(item["rows"][0]["sample"]))
                provenance.append({"block": block, "order": PAIR_ORDERS[block - 1],
                    "A": a["original_record"], "B": b["original_record"]})
            result[name].append({"endpoint": endpoint["id"],
                "input_kind": "fresh_process_walltime" if name == "cli" else "criterion_sample_groups",
                **estimator.compare(control, candidate, **ESTIMATOR_ARGS, expected_sample_groups=1 if name == "cli" else 40),
                "paired_runs": provenance})
    return result


def validate_results(value):
    exact_fields(value, PHASES, "analysis phase inventory differs")
    for name, rows in value.items():
        require(type(rows) is list and len(rows) == PHASE_COUNTS[name][2], "complete analysis rows required")
        for row in rows:
            exact_fields(row, SCREEN_FIELDS if name == "screen" else RESULT_FIELDS, "analysis result fields differ")
            for key in ("control_median_ns", "candidate_median_ns", "candidate_control_ratio", "candidate_minus_control_ns"):
                require(numeric(row[key]), "analysis point estimate differs")
            if name == "screen":
                exact_fields(row["process_provenance"], ("A", "B"), "screen provenance fields differ")
                require(all(valid_identity(item) for item in row["process_provenance"].values()), "screen provenance differs")
                continue
            require(all(type(row[key]) is int for key in ("resamples", "seed", "process_rounds"))
                and row["resamples"] == 100000 and row["seed"] == 20260911 and row["process_rounds"] == 12
                and type(row["confidence_level"]) is float and row["confidence_level"] == 0.95
                and type(row["sample_groups_per_round"]) is list and len(row["sample_groups_per_round"]) == 12
                and all(type(item) is int and item == (1 if name == "cli" else 40) for item in row["sample_groups_per_round"]),
                "analysis estimator counts differ")
            for key in ("control_median_ci_ns", "candidate_median_ci_ns", "candidate_control_ratio_ci", "candidate_minus_control_ci_ns"):
                require(type(row[key]) is list and len(row[key]) == 2 and all(numeric(x) for x in row[key])
                    and row[key][0] <= row[key][1], "analysis interval differs")
            require(type(row["per_round"]) is list and len(row["per_round"]) == 12
                and type(row["paired_runs"]) is list and len(row["paired_runs"]) == 12, "analysis paired rounds differ")
            for block, (pair, values) in enumerate(zip(row["paired_runs"], row["per_round"], strict=True), 1):
                exact_fields(pair, ("block", "order", "A", "B"), "paired provenance fields differ")
                exact_fields(values, ("control_median_ns", "candidate_median_ns", "candidate_control_ratio"), "round fields differ")
                require(type(pair["block"]) is int and pair["block"] == block and pair["order"] == PAIR_ORDERS[block - 1]
                    and all(valid_identity(pair[arm]) for arm in ("A", "B"))
                    and all(numeric(item, positive=True) for item in values.values()), "analysis paired provenance differs")
    return value


def admit_payload(payload, manifest):
    require(type(payload) is dict and set(payload) == PAYLOAD
        and type(manifest) is dict and set(manifest) == {"schema", "payload"} and manifest["schema"] == SCHEMA
        and type(manifest["payload"]) is dict and set(manifest["payload"]) == PAYLOAD
        and all(valid_identity(item) for item in manifest["payload"].values())
        and manifest["payload"] == {name: identity(data) for name, data in sorted(payload.items())},
        "exact allowlisted payload differs")
    require(all(type(data) is bytes and 0 < len(data) <= MAX_MEMBER for data in payload.values())
        and sum(map(len, payload.values())) <= MAX_TOTAL, "portable byte bounds differ")
    require(payload["analyze.py"] == read_regular(Path(__file__).resolve()), "analyzer source differs")
    for name, data in payload.items():
        if name != "analyze.py":
            content_scan(data)
    study = validate_study(payload["study.json"])
    require(identity(payload["README.md"]) == study["readme"], "public explanation differs")
    require(digest(payload["samples.json"]) == SAMPLES_SHA and digest(payload["analysis.json"]) == ANALYSIS_SHA,
        "frozen sample or analysis projection differs")
    rows = validate_samples(parse_json(payload["samples.json"]), study)
    expected = validate_results(parse_json(payload["analysis.json"]))
    analysis = recompute(study, rows, payload["estimator.py"])
    require(pretty(expected) == pretty(analysis), "complete unrounded reanalysis differs")
    return {"schema": "uv-future.pr1734-portable-admission.v1", "accepted": True,
        "study": study, "analysis": analysis, "publication_authorized": False}


def admit_portable(bundle, expected_manifest_sha256):
    bundle = Path(os.path.abspath(bundle))
    require(bundle.is_absolute() and bundle.resolve(strict=True) == bundle and bundle.is_dir()
        and not bundle.is_symlink() and hash_string(expected_manifest_sha256), "external manifest pin required")
    require({item.name for item in bundle.iterdir()} == PAYLOAD | {"manifest.json"}, "portable file inventory differs")
    manifest_data = read_regular(bundle / "manifest.json")
    require(digest(manifest_data) == expected_manifest_sha256, "manifest digest differs")
    payload = {name: read_regular(bundle / name) for name in sorted(PAYLOAD)}
    return admit_payload(payload, parse_json(manifest_data)) | {"manifest_sha256": expected_manifest_sha256}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    args = parser.parse_args()
    print(json.dumps(admit_portable(args.bundle, args.manifest_sha256), indent=2, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
