import urllib3

def do():
    r = urllib3.request('GET', 'https://httpbin.org/get')
    print(r.data)
