def main():
    print("Hello from futzed-lzma!")


if __name__ == "__main__":
    main()
