def main():
    print("Hello from futzed-bz2!")


if __name__ == "__main__":
    main()
